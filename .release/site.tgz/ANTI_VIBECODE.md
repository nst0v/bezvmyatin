# Anti-vibecode scorecard

Итог: **28 PASS**, **2 NOT APPLICABLE**, **0 JUSTIFIED EXCEPTION**.

| № | Критерий | Статус | Результат |
|---:|---|---|---|
| 1 | Harsh gradients | PASS | Градиенты отсутствуют. |
| 2 | Lucide icons | PASS | Библиотеки иконок не используются. |
| 3 | Pure white background | PASS | Используются тёплые нейтральные поверхности. |
| 4 | Rainbow coloring | PASS | Один коммерческий акцентный цвет. |
| 5 | Drop shadows | PASS | Тени отсутствуют. |
| 6 | Three feature cards | PASS | Контент оформлен строками и списками, не карточками. |
| 7 | Emojis | PASS | Emoji отсутствуют. |
| 8 | Liquid glass | PASS | Прозрачные стеклянные панели отсутствуют. |
| 9 | Em dashes | PASS | Тексты написаны прямым естественным синтаксисом. |
| 10 | AI fonts | PASS | Используется системная типографика. |
| 11 | Colored left stripe | PASS | Декоративные полосы отсутствуют. |
| 12 | Fake testimonials | PASS | Отзывов на сайте нет. |
| 13 | Bento grids | PASS | Bento-композиция отсутствует. |
| 14 | Terminal window | PASS | Терминал отсутствует. |
| 15 | “It’s not X, it’s Y” | PASS | Клишированные противопоставления отсутствуют. |
| 16 | Checkmark bullets | PASS | Списки с одинаковыми галочками отсутствуют. |
| 17 | Three pricing tiers | PASS | Тарифы и неподтверждённые цены отсутствуют. |
| 18 | No real product demo | PASS | Работает выбор фото, валидация и создание черновика. |
| 19 | Soft corner radius | PASS | Радиусы минимальны и функциональны. |
| 20 | Purple and black | PASS | Палитра нейтральная с красно-оранжевым акцентом. |
| 21 | Skeleton loaders | NOT APPLICABLE | Асинхронной загрузки нет. |
| 22 | Radial orbs | PASS | Светящиеся круги отсутствуют. |
| 23 | Dot grids | PASS | Точечные сетки отсутствуют. |
| 24 | Sparkle icons | PASS | Sparkle-декор отсутствует. |
| 25 | Animated arrows | PASS | Анимированные стрелки отсутствуют. |
| 26 | Terms of service | NOT APPLICABLE | Нет оплаты, аккаунта, заказа или подписки. |
| 27 | Privacy | PASS | Форма ничего не отправляет, согласие не отмечено заранее. |
| 28 | Hover animations | PASS | Hover меняет только состояние ссылок и кнопок. |
| 29 | Neon colors | PASS | Неоновые цвета отсутствуют. |
| 30 | Basic pastel cards | PASS | Пастельные карточки отсутствуют. |
