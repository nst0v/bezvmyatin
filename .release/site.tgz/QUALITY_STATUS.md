# Quality status

- Result: **passed**
- `npm install`: passed, 0 vulnerabilities
- `npm run lint`: passed
- `npm run typecheck`: passed
- `npm run test`: passed, 6/6
- `npm run build`: passed
- Browser console errors: 0
- Horizontal overflow: none at 360, 390, 768, 1024, 1440 and 1920 px
- Interactions checked: mobile menu, Escape close, FAQ, form errors, successful draft generation
